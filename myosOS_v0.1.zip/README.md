# myosOS v0.1.0

A minimalist, lightweight 32-bit monolithic-style research kernel built from scratch using C and Assembly, booting via the Multiboot standard.

## Features
- **Pure Text Mode**: Runs inside standard x86 80x25 VGA text memory layout (`0xB8000`).
- **Multi-color Console UI**: Custom print implementation supporting individual foreground colors (Red for branding, Blue for prompts, Green for execution text).
- **Keyboard Input Handling**: Custom I/O port driver reading from PS/2 keyboard controller (`0x60`/`0x64`) via Polling.
- **Command Parser**: Built-in string comparison execution engine.
  - Supported Shell commands: `clear`, `help`, `about`, `version`, `logo`, `matrix`.

## Project Structure
- `boot.asm`: Early boot stage Assembly entry point setting up the stack and verifying Multiboot signatures.
- `kernel.c`: Core kernel logic handling string operations, hardware I/O, memory layouts, and shell interactions.
- `linker.ld`: Linker script alignment ensuring code layouts begin precisely at the 1MB physical RAM threshold.
- `Makefile`: Streamlined build automation script for compilation and QEMU execution.

## How to Build and Run
Ensure you have `nasm`, `LLVM/Clang`, `lld`, and `qemu-system-x86_64` installed on your build environment.

To compile the source code and assemble the raw kernel binary:
```bash
make
```

To boot the kernel inside the QEMU emulator with VNC output mapping enabled:
```bash
make run
```
