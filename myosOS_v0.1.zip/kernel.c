unsigned char inb(unsigned short port) {
    unsigned char ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

unsigned char get_ascii(unsigned char scancode) {
    unsigned char kbd_us[128] = {
        0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
        '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
        0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0,
        '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' '
    };
    if (scancode & 0x80) return 0;
    return kbd_us[scancode];
}

int strcmp(const char* s1, const char* s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(unsigned char*)s1 - *(unsigned char*)s2;
}

void print_string(volatile char* vm, int* idx, const char* str, unsigned char color) {
    for (int i = 0; str[i] != '\0'; i++) {
        vm[(*idx) * 2] = str[i];
        vm[(*idx) * 2 + 1] = color;
        (*idx)++;
    }
}

void newline(int* idx) {
    int current_row = (*idx) / 80;
    *idx = (current_row + 1) * 80;
    if (*idx >= 2000) {
        for (int i = 160; i < 2000; i++) {
            ((volatile char*)0xB8000)[i * 2] = ' ';
            ((volatile char*)0xB8000)[i * 2 + 1] = 0x0A;
        }
        *idx = 160;
    }
}

void kernel_main(void) {
    volatile char* video_memory = (volatile char*) 0xB8000;
    
    for (int i = 0; i < 2000; i++) {
        video_memory[i * 2] = ' ';
        video_memory[i * 2 + 1] = 0x07;
    }

    int intro_idx = 0;
    print_string(video_memory, &intro_idx, "Welcome to myosOS v0.1! Ready for research...", 0x0C);

    int v_idx = 160;
    print_string(video_memory, &v_idx, "Type here: ", 0x09);
    int start_pos = v_idx;

    unsigned char last_scancode = 0;
    char cmd_buf[100];
    int cmd_len = 0;

    while (1) {
        unsigned char status = inb(0x64);
        if (status & 0x01) {
            unsigned char scancode = inb(0x60);
            if (scancode != last_scancode) {
                last_scancode = scancode;
                if (!(scancode & 0x80)) {
                    unsigned char ascii = get_ascii(scancode);
                    if (ascii == '\b') {
                        if (v_idx > start_pos) {
                            v_idx--;
                            video_memory[v_idx * 2] = ' ';
                            video_memory[v_idx * 2 + 1] = 0x0A;
                            if (cmd_len > 0) cmd_len--;
                        }
                    } else if (ascii == '\n') {
                        cmd_buf[cmd_len] = '\0';
                        newline(&v_idx);

                        if (strcmp(cmd_buf, "clear") == 0) {
                            for (int i = 160; i < 2000; i++) {
                                video_memory[i * 2] = ' ';
                                video_memory[i * 2 + 1] = 0x0A;
                            }
                            v_idx = 160;
                        } else if (strcmp(cmd_buf, "help") == 0) {
                            print_string(video_memory, &v_idx, "Commands: clear, help, about, version, logo, matrix", 0x0A);
                            newline(&v_idx);
                        } else if (strcmp(cmd_buf, "about") == 0) {
                            print_string(video_memory, &v_idx, "myosOS: A custom research monolithic-style kernel.", 0x0A);
                            newline(&v_idx);
                        } else if (strcmp(cmd_buf, "version") == 0) {
                            print_string(video_memory, &v_idx, "myosOS Kernel Version 0.1.0 (Early Boot Stage)", 0x0A);
                            newline(&v_idx);
                        } else if (strcmp(cmd_buf, "logo") == 0) {
                            print_string(video_memory, &v_idx, "M   M  Y   Y   OOO    SSS ", 0x0C); newline(&v_idx);
                            print_string(video_memory, &v_idx, "MM MM   Y Y   O   O  S    ", 0x0C); newline(&v_idx);
                            print_string(video_memory, &v_idx, "M M M    Y    O   O   SSS ", 0x0C); newline(&v_idx);
                            print_string(video_memory, &v_idx, "M   M    Y    O   O      S", 0x0C); newline(&v_idx);
                            print_string(video_memory, &v_idx, "M   M    Y     OOO    SSS ", 0x0C); newline(&v_idx);
                        } else if (strcmp(cmd_buf, "matrix") == 0) {
                            print_string(video_memory, &v_idx, "Wake up, Neo... The Matrix has you...", 0x0A);
                            newline(&v_idx);
                            print_string(video_memory, &v_idx, "0101010101010101010101010101010101", 0x0A);
                            newline(&v_idx);
                        } else if (cmd_len > 0) {
                            print_string(video_memory, &v_idx, "Unknown command.", 0x0C);
                            newline(&v_idx);
                        }

                        print_string(video_memory, &v_idx, "Type here: ", 0x09);
                        start_pos = v_idx;
                        cmd_len = 0;
                    } else if (ascii != 0) {
                        video_memory[v_idx * 2] = ascii;
                        video_memory[v_idx * 2 + 1] = 0x0A;
                        v_idx++;
                        if (cmd_len < 99) {
                            cmd_buf[cmd_len++] = ascii;
                        }
                        if (v_idx >= 2000) {
                            for (int i = 160; i < 2000; i++) {
                                video_memory[i * 2] = ' ';
                                video_memory[i * 2 + 1] = 0x0A;
                            }
                            v_idx = 160;
                            print_string(video_memory, &v_idx, "Type here: ", 0x09);
                            start_pos = v_idx;
                            cmd_len = 0;
                        }
                    }
                }
            }
        }
    }
}
